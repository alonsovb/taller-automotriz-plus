package pkgData;

// Sub-clase lista de mis autos
public class cMyCars {

    private cCar _car;
    public cMyCars sig;

    public cMyCars(cCar myCar) {
        _car = myCar;
    }

    public cCar getCar() {
        return _car;
    }


}
