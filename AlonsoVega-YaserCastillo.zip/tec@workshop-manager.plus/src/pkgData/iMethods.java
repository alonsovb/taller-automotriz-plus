package pkgData;

// Inteface métodos
public interface iMethods {

    public Boolean Exists(Object element);
    public void Modify(Object element, Object[] newValues);

}
